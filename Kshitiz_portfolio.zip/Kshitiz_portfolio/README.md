# Kshitiz B.K. Portfolio

Built from the original portfolio source while preserving its signature animations: scroll-linked profile photo, reveal motion, custom cursor, magnetic buttons, tilt cards, GSAP floating parallax, horizontal showcase, journey progress, and code typing.

## Real Sikshya AI assets
The five supplied screenshots are kept in `images/` without WebP conversion so the original assets are served directly.

## URLs to fill
Edit the `LINKS` object in `index.html` and `contact.html` with real GitHub, LinkedIn, Instagram, TikTok and email values. Project `url` / `github` values are also intentionally empty until real URLs are supplied.
